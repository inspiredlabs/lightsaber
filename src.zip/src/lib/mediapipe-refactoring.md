```
.src/lib/mediapipe/hands/hand_landmark_full.tflite
.src/lib/mediapipe/hands/hand_landmark_lite.tflite
.src/lib/mediapipe/hands/hands_solution_packed_assets.data
.src/lib/mediapipe/hands/hands_solution_simd_wasm_bin.data
.src/lib/mediapipe/hands/hands_solution_simd_wasm_bin.wasm
.src/lib/mediapipe/hands/hands_solution_wasm_bin.wasm
.src/lib/mediapipe/hands/package.json```
